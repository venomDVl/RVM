# (c) @AbirHasan2005

from dotenv import load_dotenv
import bot.client

load_dotenv()
bot = bot.client.Client()
