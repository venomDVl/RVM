# (c) @AbirHasan2005

import bot


if __name__ == "__main__":
    bot.bot.run()
